#!/bin/bash

# Ten10 Project Management - Setup Script
# This script sets up the application for local development

set -e

echo "🚀 Setting up Ten10 Project Management..."
echo "========================================"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version 18+ is required. Current version: $(node -v)"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"

# Kill any existing processes on ports 3001 and 5173
echo "🔄 Checking for existing processes..."
lsof -ti:3001 | xargs kill -9 2>/dev/null || true
lsof -ti:5173 | xargs kill -9 2>/dev/null || true
echo "✅ Cleared existing processes"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Fix security vulnerabilities
echo "🔒 Fixing security vulnerabilities..."
npm audit fix --force >/dev/null 2>&1 || true

# Set up environment files
echo "⚙️  Setting up environment files..."

# Backend environment
if [ ! -f "packages/backend/.env" ]; then
    cp packages/backend/.env.example packages/backend/.env
    echo "✅ Created backend .env file"
else
    echo "⚠️  Backend .env file already exists"
fi

# Frontend environment
if [ ! -f "packages/frontend/.env" ]; then
    if [ -f "packages/frontend/.env.example" ]; then
        cp packages/frontend/.env.example packages/frontend/.env
        echo "✅ Created frontend .env file"
    else
        # Create a basic frontend .env file
        cat > packages/frontend/.env << EOF
VITE_API_URL=http://localhost:3001/api
EOF
        echo "✅ Created frontend .env file"
    fi
else
    echo "⚠️  Frontend .env file already exists"
fi

# Set up database
echo "🗄️  Setting up database..."
cd packages/backend

# Clean up any existing Prisma client
rm -rf node_modules/.prisma 2>/dev/null || true

# Generate Prisma client with retry
echo "Generating Prisma client..."
npx prisma generate || {
    echo "⚠️ Prisma generate failed, retrying..."
    sleep 2
    npx prisma generate
}

# Push database schema
echo "Pushing database schema..."
npx prisma db push

echo "✅ Database setup complete"

cd ../..

echo ""
echo "🎉 Setup complete!"
echo "=================="
echo ""
echo "To start the application:"
echo "1. Run: npm run dev"
echo "2. Open your browser to:"
echo "   - Frontend: http://localhost:5173"
echo "   - Backend API: http://localhost:3001"
echo ""
echo "📝 Note: Make sure to configure your database URL in packages/backend/.env"
echo "   The default uses the Neon PostgreSQL database from the example."
echo ""
echo "🔧 Available commands:"
echo "   npm run dev      - Start both frontend and backend"
echo "   npm run build    - Build for production"
echo "   npm run test     - Run tests"
echo "   npm run lint     - Lint code"
echo ""